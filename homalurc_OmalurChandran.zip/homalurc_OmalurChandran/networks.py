"""
MIT License
Copyright <2017> <Hari Kripa Omalur Chandran>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE."""

import numpy as np
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def dsigmoid(y):
    return y * (1.0 - y)  

def softplus(x):
    return np.log(1 + np.exp(x))


class xor_net(object):
    """
    This is a sample class for miniproject 1.
    Args:
        data: Is a tuple, ``(x,y)``
              ``x`` is a two or one dimensional ndarray ordered such that axis 0 is independent 
              data and data is spread along axis 1. If the array had only one dimension, it implies
              that data is 1D.
              ``y`` is a 1D ndarray it will be of the same length as axis 0 or x.   
                          
    """
    def __init__(self, data, labels):
        self.x = data
        self.y = labels       
        self.params = []  # [(w,b),(w,b)] 

        self.x = np.insert(self.x,0,1,axis = 1)
        
        
        
        transpose_x = np.transpose(self.x)    # store transpose of given x
        w_i_1 = -np.random.uniform(-1,1,(self.x.shape[1],self.x.shape[1]/2 +3))   # randomly assign weights to w_i
        change_1 = np.zeros((self.x.shape[1],self.x.shape[1]/2 +3))
        w_i_3 = -np.random.uniform(-1,1,(self.x.shape[1]/2 + 4,1))   # randomly assign weights to w_i 
        change_2 = np.zeros((self.x.shape[1]/2 +4,1))

        momentum = 0.9

        learning_rate_1 = 0.01  # initialize learning rate
        learning_rate_2 = 1.0   # initialize learning rate
        learning_rate_3 = 1.0  # initialize learning rate

        alpha_regualrization = 0 # initialize alpha for regularization
        alpha_matrix = alpha_regualrization * np.eye(self.x.shape[1]) 

        
        
        count = 50000
        error = 1
        old_error = 1.1
        c = 0
        flag = 0
        new = 1
        old = 0
        while(np.absolute(new -old) >0.0000000001 or new>0.1):
            count = count - 1
            old = new
            if(count == 0):
                print "different weights"
                w_i_1 = -np.random.uniform(-1,1,(self.x.shape[1],self.x.shape[1]/2 +3))   # randomly assign weights to w_i
                change_1 = np.zeros((self.x.shape[1],self.x.shape[1]/2 +3))
                w_i_3 = -np.random.uniform(-1,1,(self.x.shape[1]/2 + 4,1))   # randomly assign weights to w_i 
                change_2 = np.zeros((self.x.shape[1]/2 +4,1))
                count = 50000


            
            # feed forward 
            l1_1 = sigmoid(np.dot(self.x, w_i_1))
            l1_1_new = np.insert(l1_1,0,1,axis = 1)
            output = sigmoid((np.dot(l1_1_new, w_i_3)))
            output[output > 0.9] = 1
            output[output < 0.1] = 0
            

            #Back propogation
            #output layer error
            self.y.shape = (self.y.shape[0], 1)
            output_error = (self.y - output)
            
            output_delta = output_error * dsigmoid(output)
            #print "dsigmoid(output)",dsigmoid(output)
            #print "output error",output_error
            
            #hidden layer error
            l1_1_error = np.dot(output_delta,np.transpose(w_i_3))
            l1_1_delta = l1_1_error * dsigmoid(l1_1_new)

            
            #update weights based on error
            w_i_3_old = w_i_3
            w_i_1_old = w_i_1

            w_i_3 = w_i_3 + learning_rate_1 * np.dot(np.transpose(l1_1_new), output_delta) + momentum*change_2
            w_i_1 = w_i_1 + learning_rate_1 * np.dot(transpose_x, l1_1_delta[:,1:]) + momentum*change_1

            change_1 = w_i_1 - w_i_1_old
            change_2 = w_i_3 - w_i_3_old

            new = np.sum(np.absolute(output_error)) / float(output.shape[0])
            
        
        self.params = (w_i_1, w_i_3)
        
        print "XOR"


        
        




  
    def get_params (self):
        """ 
        Method that should return the model parameters.
        Returns:
            tuple of numpy.ndarray: (w, b). 
        Notes:
            This code will return an empty list for demonstration purposes. A list of tuples of 
            weoghts and bias for each layer. Ordering should from input to outputt
        """
        return self.params

    def get_predictions (self, x):
        """
        Method should return the outputs given unseen data
        Args:
            x: array similar to ``x`` in ``data``. Might be of different size.
        Returns:    
            numpy.ndarray: ``y`` which is a 1D array of predictions of the same length as axis 0 of 
                            ``x`` 
        Notes:
            Temporarily returns random numpy array for demonstration purposes.                            
        """        
        # Here is where you write a code to evaluate the data and produce predictions.
        w_i_1, w_i_3 = self.params
        x = np.insert(x,0,1,axis = 1) 
        
        l1_1 = sigmoid(np.dot(x, w_i_1))
        l1_1_new = np.insert(l1_1,0,1,axis = 1)
        output = sigmoid(np.dot(l1_1_new, w_i_3))
        output[output > 0.5] = 1
        output[output < 0.5] = 0
        output.shape = (output.shape[0], )
        return output

class mlnn(xor_net):
    """
    At the moment just inheriting the network above. 
    """
    def __init__ (self, data, labels):
        #super(mlnn,self).__init__(data, labels)
        self.x = data
        self.y = labels       
        self.params = []  # [(w,b),(w,b)] 

        self.x = np.insert(self.x,0,1,axis = 1)
        self.x = self.x / self.x.max()
        
        
        transpose_x = np.transpose(self.x)    # store transpose of given x
        w_i_1 = np.random.uniform(-1,1,(self.x.shape[1],self.x.shape[1]/2))   # randomly assign weights to w_i
        change_1 = np.zeros((self.x.shape[1],self.x.shape[1]/2))
        w_i_2 = np.random.uniform(-1,1,(self.x.shape[1]/2+1,100))   # randomly assign weights to w_i
        change_2 = np.zeros((self.x.shape[1]/2+1,100))
        w_i_3 = np.random.uniform(-1,1,(101,1))   # randomly assign weights to w_i 
        change_3 = np.zeros((101,1))
        w_i_4 = np.random.uniform(0,1,(21,1))   # randomly assign weights to w_i 
        change_4 = np.zeros((21,1))

        momentum = 0.9

        learning_rate_1 = 0.001  # initialize learning rate
        learning_rate_2 = 1.0   # initialize learning rate
        learning_rate_3 = 1.0  # initialize learning rate

        alpha_regualrization = 0 # initialize alpha for regularization
        alpha_matrix = alpha_regualrization * np.eye(self.x.shape[1]) 

        
        
        
        new = 1
        old = 0

        while(new > 0.01):

            if(old==new):
                w_i_1 = np.random.uniform(-1,1,(self.x.shape[1],self.x.shape[1]/2))   # randomly assign weights to w_i
                change_1 = np.zeros((self.x.shape[1],self.x.shape[1]/2))
                w_i_2 = np.random.uniform(-1,1,(self.x.shape[1]/2+1,100))   # randomly assign weights to w_i
                change_2 = np.zeros((self.x.shape[1]/2+1,100))
                w_i_3 = np.random.uniform(-1,1,(101,1))   # randomly assign weights to w_i 
                change_3 = np.zeros((101,1))

            
            old = new

            
            # feed forward 
            l1_1 = sigmoid(np.dot(self.x, w_i_1))
            l1_1_new = np.insert(l1_1,0,1,axis = 1)

            l2_1 = sigmoid(np.dot(l1_1_new, w_i_2))
            l2_1_new = np.insert(l2_1,0,1,axis = 1)

            output = sigmoid((np.dot(l2_1_new, w_i_3)))
            
            output[output > 0.9] = 1
            output[output < 0.1] = 0
            

            # Back propogation

            self.y.shape = (self.y.shape[0], 1)

            # output error
            output_error = (self.y - output)
            
            output_delta = output_error * dsigmoid(output)
            
            #hidden layer error


            

            l2_1_error = np.dot(output_delta,np.transpose(w_i_3))
            l2_1_delta = l2_1_error * dsigmoid(l2_1_new)

            l1_1_error = np.dot(l2_1_delta[:,1:],np.transpose(w_i_2))
            l1_1_delta = l1_1_error * dsigmoid(l1_1_new)

            
            #update weights based on error
            
            w_i_3_old = w_i_3
            w_i_2_old = w_i_2
            w_i_1_old = w_i_1

            
            w_i_3 = w_i_3 + learning_rate_1 * np.dot(np.transpose(l2_1_new), output_delta) + momentum*change_3
            w_i_2 = w_i_2 + learning_rate_1 * np.dot(np.transpose(l1_1_new), l2_1_delta[:,1:]) + momentum*change_2
            w_i_1 = w_i_1 + learning_rate_1 * np.dot(transpose_x, l1_1_delta[:,1:]) + momentum*change_1

            change_1 = w_i_1 - w_i_1_old
            change_2 = w_i_2 - w_i_2_old
            change_3 = w_i_3 - w_i_3_old
            
            
            new = np.sum(np.absolute(output_error)) / float(output.shape[0])
            
            
            
            
           

        
        self.params = (w_i_1, w_i_2, w_i_3)
        
        print "WALDO"


        
        




  
    def get_params (self):
        """ 
        Method that should return the model parameters.
        Returns:
            tuple of numpy.ndarray: (w, b). 
        Notes:
            This code will return an empty list for demonstration purposes. A list of tuples of 
            weoghts and bias for each layer. Ordering should from input to outputt
        """
        return self.params

    def get_predictions (self, x):
        """
        Method should return the outputs given unseen data
        Args:
            x: array similar to ``x`` in ``data``. Might be of different size.
        Returns:    
            numpy.ndarray: ``y`` which is a 1D array of predictions of the same length as axis 0 of 
                            ``x`` 
        Notes:
            Temporarily returns random numpy array for demonstration purposes.                            
        """        
        # Here is where you write a code to evaluate the data and produce predictions.
        w_i_1, w_i_2, w_i_3 = self.params
        x = np.insert(x,0,1,axis = 1) 
        x = x / x.max()
        l1_1 = sigmoid(np.dot(x, w_i_1))
        l1_1_new = np.insert(l1_1,0,1,axis = 1)

        l2_1 = sigmoid(np.dot(l1_1_new, w_i_2))
        l2_1_new = np.insert(l2_1,0,1,axis = 1)

        output = sigmoid((np.dot(l2_1_new, w_i_3)))
        output[output > 0.4] = 1
        output[output < 0.4] = 0
        output.shape = (output.shape[0], )
        #output = np.asarray(output, dtype =int )
        return output


if __name__ == '__main__':
    pass 